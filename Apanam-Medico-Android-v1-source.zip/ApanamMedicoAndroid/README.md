# Apanam Medico Android App

Official Android wrapper for https://apanammedico.com/

Included: secure in-app store, cart/login sessions, camera/gallery/PDF prescription upload, WhatsApp/external links, downloads, Android back navigation, loading progress and offline retry.

Open this folder in Android Studio, allow Gradle sync, then use **Build > Build Bundle(s) / APK(s) > Build APK(s)**. The debug APK will be in `app/build/outputs/apk/debug/app-debug.apk`.

For Play Store release, create a private signing key and generate a signed `.aab`. Never commit the signing key.
