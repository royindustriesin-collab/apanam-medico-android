# WebView application: keep the default Android rules.
