package com.apanammedico.app;

import android.app.DownloadManager;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.view.View;
import android.webkit.CookieManager;
import android.webkit.SslErrorHandler;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ProgressBar;
import android.widget.Toast;
import androidx.activity.OnBackPressedCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.FileProvider;
import java.io.File;
import java.io.IOException;

public class MainActivity extends AppCompatActivity {
    private static final String HOME = "https://apanammedico.com/";
    private WebView webView;
    private ProgressBar progress;
    private View errorPanel;
    private ValueCallback<Uri[]> fileCallback;
    private Uri cameraUri;

    private final ActivityResultLauncher<Intent> filePicker = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), result -> {
        if (fileCallback == null) return;
        Uri[] uris = null;
        if (result.getResultCode() == RESULT_OK) {
            Intent data = result.getData();
            if (data == null || data.getData() == null) {
                if (cameraUri != null) uris = new Uri[]{cameraUri};
            } else uris = WebChromeClient.FileChooserParams.parseResult(result.getResultCode(), data);
        }
        fileCallback.onReceiveValue(uris);
        fileCallback = null;
        cameraUri = null;
    });

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        setContentView(R.layout.activity_main);
        webView = findViewById(R.id.webView);
        progress = findViewById(R.id.progress);
        errorPanel = findViewById(R.id.errorPanel);
        findViewById(R.id.retryButton).setOnClickListener(v -> loadHome());
        configureWebView();
        if (state == null) loadHome(); else webView.restoreState(state);
        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override public void handleOnBackPressed() { if (webView.canGoBack()) webView.goBack(); else finish(); }
        });
    }

    private void configureWebView() {
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(true);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setUserAgentString(s.getUserAgentString() + " ApanamMedicoAndroid/1.0");
        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true);
        webView.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                String scheme = uri.getScheme() == null ? "" : uri.getScheme();
                String host = uri.getHost() == null ? "" : uri.getHost();
                if ((scheme.equals("https") || scheme.equals("http")) && (host.equals("apanammedico.com") || host.equals("www.apanammedico.com"))) return false;
                return openExternal(uri);
            }
            @Override public void onPageStarted(WebView view, String url, Bitmap favicon) { progress.setVisibility(View.VISIBLE); }
            @Override public void onPageFinished(WebView view, String url) { errorPanel.setVisibility(View.GONE); webView.setVisibility(View.VISIBLE); }
            @Override public void onReceivedError(WebView view, WebResourceRequest req, WebResourceError error) { if (req.isForMainFrame()) showOffline(); }
            @Override public void onReceivedSslError(WebView view, SslErrorHandler handler, android.net.http.SslError error) { handler.cancel(); showOffline(); }
        });
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public void onProgressChanged(WebView view, int value) { progress.setProgress(value); progress.setVisibility(value == 100 ? View.GONE : View.VISIBLE); }
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = callback;
                launchChooser(params);
                return true;
            }
        });
        webView.setDownloadListener((url, userAgent, disposition, mimeType, length) -> {
            try {
                DownloadManager.Request request = new DownloadManager.Request(Uri.parse(url));
                request.setMimeType(mimeType);
                request.addRequestHeader("User-Agent", userAgent);
                request.addRequestHeader("Cookie", CookieManager.getInstance().getCookie(url));
                request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
                request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, "ApanamMedico-download");
                ((DownloadManager) getSystemService(DOWNLOAD_SERVICE)).enqueue(request);
                Toast.makeText(this, "डाउनलोड शुरू हो गया", Toast.LENGTH_SHORT).show();
            } catch (Exception e) { openExternal(Uri.parse(url)); }
        });
    }

    private void launchChooser(WebChromeClient.FileChooserParams params) {
        Intent content = params.createIntent();
        content.addCategory(Intent.CATEGORY_OPENABLE);
        Intent camera = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        try {
            File image = File.createTempFile("prescription_", ".jpg", getCacheDir());
            cameraUri = FileProvider.getUriForFile(this, getPackageName() + ".files", image);
            camera.putExtra(MediaStore.EXTRA_OUTPUT, cameraUri);
            camera.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
        } catch (IOException | IllegalArgumentException e) { camera = null; }
        Intent chooser = Intent.createChooser(content, "प्रिस्क्रिप्शन चुनें");
        if (camera != null) chooser.putExtra(Intent.EXTRA_INITIAL_INTENTS, new Intent[]{camera});
        try { filePicker.launch(chooser); }
        catch (ActivityNotFoundException e) {
            fileCallback.onReceiveValue(null); fileCallback = null;
            Toast.makeText(this, "फ़ाइल चुनने वाला ऐप नहीं मिला", Toast.LENGTH_SHORT).show();
        }
    }

    private boolean openExternal(Uri uri) {
        try { startActivity(new Intent(Intent.ACTION_VIEW, uri)); }
        catch (ActivityNotFoundException e) { Toast.makeText(this, "यह लिंक नहीं खुल सका", Toast.LENGTH_SHORT).show(); }
        return true;
    }
    private void loadHome() {
        if (!isOnline()) { showOffline(); return; }
        errorPanel.setVisibility(View.GONE); webView.setVisibility(View.VISIBLE); webView.loadUrl(HOME);
    }
    private boolean isOnline() {
        ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        Network network = cm.getActiveNetwork();
        return network != null && cm.getNetworkCapabilities(network) != null;
    }
    private void showOffline() { progress.setVisibility(View.GONE); webView.setVisibility(View.GONE); errorPanel.setVisibility(View.VISIBLE); }
    @Override protected void onSaveInstanceState(@NonNull Bundle outState) { webView.saveState(outState); super.onSaveInstanceState(outState); }
}
